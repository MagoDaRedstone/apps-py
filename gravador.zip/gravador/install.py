import os
import sys
import subprocess
import zipfile
import tarfile
from threading import Thread

# Links para download do FFmpeg
FFMPEG_WINDOWS_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
FFMPEG_LINUX_URL = "https://johnvansickle.com/ffmpeg/releases/ffmpeg-release.tar.xz"

# Nomes das pastas de destino
WINDOWS_DIR = "windows"
LINUX_DIR = "linux"

def create_temp_venv(venv_dir):
    """Cria um ambiente virtual temporário"""
    subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
    print(f"Ambiente virtual criado em: {venv_dir}")
    return os.path.join(venv_dir, "Scripts" if os.name == "nt" else "bin")

def install_dependencies(venv_bin):
    """Instala requests e tqdm na venv"""
    pip_path = os.path.join(venv_bin, "pip")
    subprocess.run([pip_path, "install", "requests", "tqdm"], check=True)

def download_and_extract_in_venv(venv_python, url, dest_file, extract_to):
    """Executa o download e extração de arquivos dentro da venv"""
    script = f"""
import requests
from tqdm import tqdm
import os
import zipfile
import tarfile

def download_file(url, dest_path):
    response = requests.get(url, stream=True)
    total_size = int(response.headers.get('content-length', 0))
    with open(dest_path, 'wb') as file, tqdm(
        desc=f"Baixando {{os.path.basename(dest_path)}}",
        total=total_size,
        unit='B',
        unit_scale=True,
        unit_divisor=1024,
    ) as progress_bar:
        for data in response.iter_content(chunk_size=1024):
            file.write(data)
            progress_bar.update(len(data))

def extract_file(file_path, extract_to):
    os.makedirs(extract_to, exist_ok=True)
    if file_path.endswith('.zip'):
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
    elif file_path.endswith('.tar.xz') or file_path.endswith('.tar.gz'):
        with tarfile.open(file_path, 'r:*') as tar_ref:
            tar_ref.extractall(extract_to)
    print(f"Extração concluída: {{extract_to}}")

download_file('{url}', '{dest_file}')
extract_file('{dest_file}', '{extract_to}')
"""
    subprocess.run([venv_python, "-c", script], check=True)

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Caminhos para salvar os arquivos baixados
    windows_path = os.path.join(current_dir, "ffmpeg_windows.zip")
    linux_path = os.path.join(current_dir, "ffmpeg_linux.tar.xz")

    # Pastas de destino
    windows_dir = os.path.join(current_dir, WINDOWS_DIR)
    linux_dir = os.path.join(current_dir, LINUX_DIR)

    # Criação da venv temporária
    venv_dir = os.path.join(current_dir, "temp_venv")
    venv_bin = create_temp_venv(venv_dir)

    try:
        # Instala dependências na venv
        install_dependencies(venv_bin)

        # Caminho do Python na venv
        venv_python = os.path.join(venv_bin, "python")

        # Threads para download e extração simultâneos dentro da venv
        print("Iniciando downloads simultâneos...")
        windows_thread = Thread(target=download_and_extract_in_venv,
                                 args=(venv_python, FFMPEG_WINDOWS_URL, windows_path, windows_dir))
        linux_thread = Thread(target=download_and_extract_in_venv,
                               args=(venv_python, FFMPEG_LINUX_URL, linux_path, linux_dir))

        # Inicia as threads
        windows_thread.start()
        linux_thread.start()

        # Aguarda as threads finalizarem
        windows_thread.join()
        linux_thread.join()

        # Verificando se os arquivos foram extraídos
        print("\nVerificando arquivos...")
        if os.path.exists(windows_dir) and os.listdir(windows_dir):
            print(f"Arquivos para Windows encontrados em: {windows_dir}")
        else:
            print(f"Erro: Nenhum arquivo encontrado em: {windows_dir}")

        if os.path.exists(linux_dir) and os.listdir(linux_dir):
            print(f"Arquivos para Linux encontrados em: {linux_dir}")
        else:
            print(f"Erro: Nenhum arquivo encontrado em: {linux_dir}")

        # Limpando os arquivos baixados
        print("\nLimpando arquivos baixados...")
        if os.path.exists(windows_path):
            os.remove(windows_path)
        if os.path.exists(linux_path):
            os.remove(linux_path)

    finally:
        # Remoção da venv temporária
        if os.path.exists(venv_dir):
            import shutil
            shutil.rmtree(venv_dir)
            print(f"\nAmbiente virtual temporário removido: {venv_dir}")

    print("\nProcesso concluído!")

if __name__ == "__main__":
    main()
