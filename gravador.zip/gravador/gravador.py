import os
import subprocess
import sys
import time
import signal

def find_ffmpeg_in_script_dir():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(script_dir):
        if 'ffmpeg' in files:
            return os.path.join(root, 'ffmpeg')
    return None

def convert_to_seconds(time_str):
    """Converte o tempo no formato hh:mm:ss para segundos."""
    parts = time_str.split(":")
    if len(parts) == 3:  # Formato hh:mm:ss
        hours, minutes, seconds = map(int, parts)
    elif len(parts) == 2:  # Formato mm:ss
        hours, minutes, seconds = 0, int(parts[0]), int(parts[1])
    else:
        hours, minutes, seconds = 0, 0, int(parts[0])
    return hours * 3600 + minutes * 60 + seconds

def record_screen(ffmpeg_path, output_file, framerate, quality, duration):
    if not ffmpeg_path:
        print("ffmpeg não encontrado!")
        return

    # Se ffmpeg for encontrado, verifica se é executável
    if sys.platform == "win32" and not ffmpeg_path.endswith(".exe"):
        ffmpeg_path += ".exe"

    if not os.access(ffmpeg_path, os.X_OK):
        print(f"O arquivo {ffmpeg_path} não é executável!")
        return

    # Configuração do comando com base na escolha do usuário
    if sys.platform == "win32":
        command = [
            ffmpeg_path, "-f", "gdigrab", "-framerate", str(framerate), "-i", "desktop", "-q:v", str(quality), output_file
        ]
    else:
        command = [
            ffmpeg_path, "-f", "x11grab", "-framerate", str(framerate), "-i", ":0.0", "-q:v", str(quality), output_file
        ]

    # Inicia a gravação com subprocess, redirecionando a saída e erro para PIPE
    sys.stdout.write("\033[H\033[J")  # Limpa o terminal
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Aguardar o tempo de gravação antes de interromper
    start_time = time.time()
    while True:
        elapsed_time = time.time() - start_time
        remaining_time = duration - elapsed_time
        if remaining_time <= 0:
            break

        # Converte o tempo restante em horas, minutos e segundos
        hours, remainder = divmod(int(remaining_time), 3600)
        minutes, seconds = divmod(remainder, 60)
        time_format = f"{hours:02}:{minutes:02}:{seconds:02}"

        # Exibe o tempo restante no formato 00:00:00
        print(f"Tempo restante: {time_format}", end="\r")
        time.sleep(1)

    # Interrompe o ffmpeg após o tempo de gravação
    print(f"\nTempo esgotado. Interrompendo a gravação...")
    process.send_signal(signal.SIGINT)  # Envia o sinal de interrupção (Ctrl+C)

    # Aguarda o término do processo
    process.wait()
    print(f"A gravação foi concluída e salva em {output_file}.")

def show_config_menu():
    sys.stdout.write("\033[H\033[J")  # Limpa o terminal
    print("\n===============================")
    print("  Configuração do Gravador de Tela")
    print("===============================")

    # Pergunta ao usuário sobre o framerate
    framerate = input("Digite o framerate (ex: 30): ")
    framerate = int(framerate) if framerate.isdigit() else 30

    # Pergunta ao usuário sobre a qualidade de gravação
    quality = input("Digite a qualidade (ex: 0 para melhor qualidade, 51 para pior): ")
    quality = int(quality) if quality.isdigit() else 0

    # Escolher o nome do arquivo de saída
    output_file = input("Digite o nome do arquivo de saída (ex: output.mp4): ")
    if not output_file:
        output_file = "output.mp4"

    # Pergunta sobre o tempo de gravação no formato hh:mm:ss
    duration_input = input("Digite o tempo de gravação (ex: 01:10:20 para 1h 10m 20s): ")
    try:
        duration = convert_to_seconds(duration_input)
    except ValueError:
        print("Formato de tempo inválido. Usando 1 minuto como padrão.")
        duration = 60

    # Tenta encontrar o ffmpeg na pasta
    ffmpeg_path = find_ffmpeg_in_script_dir()
    if not ffmpeg_path:
        print("Não foi possível encontrar o ffmpeg!")
        return

    # Inicia a gravação com as configurações fornecidas
    print(f"Iniciando a gravação com framerate {framerate} e qualidade {quality}...")
    print(f"A gravação será salva em {output_file}. Tempo de gravação: {duration // 60} minutos.\n")

    # Inicia a gravação
    record_screen(ffmpeg_path, output_file, framerate, quality, duration)

if __name__ == "__main__":
    show_config_menu()
